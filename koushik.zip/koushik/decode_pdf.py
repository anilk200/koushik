from pypdf import PdfReader

pdf_path = r'C:\Users\anilk30\Downloads\Python Assignment_Dashboard_Automation_OrangeHRM (1).pdf'
reader = PdfReader(pdf_path)
print(f"Pages: {len(reader.pages)}")
for i, page in enumerate(reader.pages):
    text = page.extract_text()
    print(f"\n=== PAGE {i+1} ===\n{text}")
