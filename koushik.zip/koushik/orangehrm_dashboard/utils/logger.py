"""
utils/logger.py
---------------
Provides a centralised logger for every automation step.
Logs are written to both the console and a rotating file under /logs.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from datetime import datetime

from orangehrm_dashboard.config import LOG_DIR


def get_logger(name: str = "orangehrm") -> logging.Logger:
    """
    Returns a configured logger instance.

    Parameters
    ----------
    name : str
        Logger name (used to create a dedicated log file).

    Returns
    -------
    logging.Logger
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers if called multiple times
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    # -----------------------------------------------------------------------
    # Formatter
    # -----------------------------------------------------------------------
    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # -----------------------------------------------------------------------
    # Console handler  (INFO and above)
    # -----------------------------------------------------------------------
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(fmt)
    logger.addHandler(console_handler)

    # -----------------------------------------------------------------------
    # Rotating file handler  (DEBUG and above, max 5 MB × 3 backups)
    # -----------------------------------------------------------------------
    timestamp = datetime.now().strftime("%Y%m%d")
    log_file = os.path.join(LOG_DIR, f"{name}_{timestamp}.log")
    file_handler = RotatingFileHandler(
        log_file, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger
