"""
utils/export.py
---------------
Exports employee data extracted from OrangeHRM to CSV and Excel formats.
"""

import csv
import os
from datetime import datetime
from typing import List, Dict, Any

from orangehrm_dashboard.config import OUTPUT_DIR
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("export")


def export_to_csv(data: List[Dict[str, Any]], filename: str = None) -> str:
    """
    Write a list of dicts to a CSV file inside the output directory.

    Parameters
    ----------
    data     : list of dicts  – rows to write
    filename : str            – optional custom file name

    Returns
    -------
    str  – absolute path of the created CSV file
    """
    if not data:
        logger.warning("export_to_csv called with empty data – skipping.")
        return ""

    if not filename:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"employees_{ts}.csv"

    filepath = os.path.join(OUTPUT_DIR, filename)
    fieldnames = list(data[0].keys())

    try:
        with open(filepath, "w", newline="", encoding="utf-8") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)

        logger.info("CSV exported → %s  (%d rows)", filepath, len(data))
        return filepath

    except OSError as exc:
        logger.error("Failed to write CSV: %s", exc)
        return ""


def export_to_excel(data: List[Dict[str, Any]], filename: str = None) -> str:
    """
    Write a list of dicts to an Excel (.xlsx) file using openpyxl.

    Parameters
    ----------
    data     : list of dicts  – rows to write
    filename : str            – optional custom file name

    Returns
    -------
    str  – absolute path of the created Excel file, or "" on failure
    """
    try:
        import openpyxl  # optional dependency
    except ImportError:
        logger.warning("openpyxl not installed – skipping Excel export.")
        return ""

    if not data:
        logger.warning("export_to_excel called with empty data – skipping.")
        return ""

    if not filename:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"employees_{ts}.xlsx"

    filepath = os.path.join(OUTPUT_DIR, filename)
    fieldnames = list(data[0].keys())

    try:
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Employees"

        # Header row  (bold)
        ws.append(fieldnames)
        for cell in ws[1]:
            cell.font = openpyxl.styles.Font(bold=True)

        # Data rows
        for row in data:
            ws.append([row.get(k, "") for k in fieldnames])

        # Auto-fit column widths (best-effort)
        for col in ws.columns:
            max_len = max((len(str(cell.value or "")) for cell in col), default=0)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)

        wb.save(filepath)
        logger.info("Excel exported → %s  (%d rows)", filepath, len(data))
        return filepath

    except Exception as exc:  # noqa: BLE001
        logger.error("Failed to write Excel: %s", exc)
        return ""
