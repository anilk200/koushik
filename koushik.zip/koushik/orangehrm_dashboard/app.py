"""
app.py
------
Flask backend for the OrangeHRM Dashboard Automation tool.

Routes
------
GET  /            → Render the dashboard UI
POST /run         → Trigger automation, return JSON result
GET  /status      → Health-check endpoint
GET  /download/<filename> → Download generated CSV/Excel files
"""

import os
from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    send_from_directory,
    abort,
)

from orangehrm_dashboard.config import (
    SECRET_KEY, FLASK_HOST, FLASK_PORT, FLASK_DEBUG,
    OUTPUT_DIR, DEFAULT_USERNAME, DEFAULT_PASSWORD,
)
from orangehrm_dashboard.automation.tasks.employee_task import run_employee_automation
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("flask_app")

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app() -> Flask:
    """Create and configure the Flask application."""
    app = Flask(
        __name__,
        template_folder=os.path.join(os.path.dirname(__file__), "templates"),
        static_folder=os.path.join(os.path.dirname(__file__), "static"),
    )
    app.secret_key = SECRET_KEY

    # -----------------------------------------------------------------------
    # Routes
    # -----------------------------------------------------------------------

    @app.route("/", methods=["GET"])
    def index():
        """Serve the main dashboard page."""
        return render_template(
            "index.html",
            default_username=DEFAULT_USERNAME,
            default_password=DEFAULT_PASSWORD,
        )

    @app.route("/run", methods=["POST"])
    def run_automation():
        """
        Trigger the full OrangeHRM automation sequence.

        Expected JSON body:
        {
            "username":    "Admin",
            "password":    "admin123",
            "first_name":  "John",
            "last_name":   "Doe",
            "employee_id": "EMP001"   // optional
        }

        Returns JSON result from run_employee_automation().
        """
        data = request.get_json(force=True, silent=True) or {}

        username    = data.get("username", "").strip()
        password    = data.get("password", "").strip()
        first_name  = data.get("first_name", "").strip()
        last_name   = data.get("last_name", "").strip()
        employee_id = data.get("employee_id", "").strip()

        # Basic validation
        errors = []
        if not username:
            errors.append("Username is required.")
        if not password:
            errors.append("Password is required.")
        if not first_name:
            errors.append("First name is required.")
        if not last_name:
            errors.append("Last name is required.")

        if errors:
            return jsonify({"status": "failure", "message": " | ".join(errors)}), 400

        logger.info(
            "Automation requested: user='%s', employee='%s %s'",
            username, first_name, last_name,
        )

        result = run_employee_automation(
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name,
            employee_id=employee_id,
        )

        # Convert absolute paths to relative filenames for the download endpoint
        for key in ("csv_path", "excel_path", "screenshot"):
            if result.get(key):
                result[key] = os.path.basename(result[key])

        http_code = 200 if result["status"] == "success" else 500
        return jsonify(result), http_code

    @app.route("/download/<path:filename>", methods=["GET"])
    def download_file(filename: str):
        """Download a generated output file (CSV / Excel / screenshot)."""
        # Security: only serve files from the output directory
        safe_name = os.path.basename(filename)
        file_path = os.path.join(OUTPUT_DIR, safe_name)
        if not os.path.isfile(file_path):
            abort(404, description=f"File '{safe_name}' not found.")
        return send_from_directory(OUTPUT_DIR, safe_name, as_attachment=True)

    @app.route("/status", methods=["GET"])
    def health_check():
        """Simple health-check endpoint."""
        return jsonify({"status": "ok", "service": "OrangeHRM Dashboard Automation"})

    return app


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app = create_app()
    logger.info("Starting Flask server at http://%s:%s", FLASK_HOST, FLASK_PORT)
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
