"""
automation/pages/login_page.py
-------------------------------
Page Object for the OrangeHRM Login page.
URL: https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
"""

from selenium.webdriver.common.by import By

from orangehrm_dashboard.automation.pages.base_page import BasePage
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("login_page")

# ---------------------------------------------------------------------------
# Locators
# ---------------------------------------------------------------------------
_USERNAME_INPUT  = (By.NAME, "username")
_PASSWORD_INPUT  = (By.NAME, "password")
_LOGIN_BUTTON    = (By.CSS_SELECTOR, "button[type='submit']")
_ERROR_MESSAGE   = (By.CSS_SELECTOR, ".oxd-alert-content-text")
_DASHBOARD_TITLE = (By.CSS_SELECTOR, ".oxd-topbar-header-breadcrumb h6")


class LoginPage(BasePage):
    """Encapsulates all interactions with the OrangeHRM login screen."""

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def load(self, base_url: str) -> "LoginPage":
        """Open the login page."""
        self.open(f"{base_url.rstrip('/')}/web/index.php/auth/login")
        logger.info("Login page loaded.")
        return self

    def enter_username(self, username: str) -> "LoginPage":
        self.safe_send_keys(*_USERNAME_INPUT, username)
        logger.debug("Username entered.")
        return self

    def enter_password(self, password: str) -> "LoginPage":
        self.safe_send_keys(*_PASSWORD_INPUT, password)
        logger.debug("Password entered.")
        return self

    def click_login(self) -> "LoginPage":
        self.safe_click(*_LOGIN_BUTTON)
        logger.info("Login button clicked.")
        return self

    def login(self, username: str, password: str) -> bool:
        """
        Full login flow.

        Returns
        -------
        bool  True on success, False on failure.
        """
        self.enter_username(username)
        self.enter_password(password)
        self.click_login()
        return self.is_login_successful()

    # ------------------------------------------------------------------
    # Assertions / state checks
    # ------------------------------------------------------------------

    def is_login_successful(self) -> bool:
        """Return True if the Dashboard header appears after login."""
        try:
            self.wait_for_visible(*_DASHBOARD_TITLE)
            logger.info("Login successful – Dashboard visible.")
            return True
        except Exception:  # noqa: BLE001
            error_msg = self._get_error_message()
            logger.error("Login failed. Error shown: '%s'", error_msg)
            return False

    def _get_error_message(self) -> str:
        try:
            return self.find(*_ERROR_MESSAGE).text
        except Exception:  # noqa: BLE001
            return "(no error message found)"
