"""
automation/pages/pim_page.py
-----------------------------
Page Object for the OrangeHRM PIM (Personnel Information Management) module.
Covers:
  • Navigating to PIM → Employee List
  • Adding a new employee
  • Extracting the employee list table

Locators verified against:
  https://opensource-demo.orangehrmlive.com  (OrangeHRM v5.x / Vue.js frontend)
"""

import time
from typing import List, Dict

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

from orangehrm_dashboard.automation.pages.base_page import BasePage
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("pim_page")

# ---------------------------------------------------------------------------
# Locators  (verified against live OrangeHRM v5 Vue.js DOM)
# ---------------------------------------------------------------------------

# --- Sidebar navigation ---
# The sidebar uses <a> tags with a nested <span class="oxd-main-menu-item--name">
# Multiple fallback selectors are tried in code, most → least specific.
_PIM_MENU_LINK       = (By.CSS_SELECTOR, "a.oxd-main-menu-item[href*='viewPimModule']")
_PIM_MENU_SPAN       = (By.XPATH,
                        "//nav//span[contains(@class,'oxd-main-menu-item--name')"
                        " and normalize-space(text())='PIM']")
_PIM_MENU_TEXT       = (By.XPATH,
                        "//ul[contains(@class,'oxd-main-menu')]"
                        "//a[.//span[normalize-space(text())='PIM']]")

# --- Employee List page ---
_ADD_EMPLOYEE_BTN    = (By.XPATH,
                        "//button[contains(@class,'oxd-button') and "
                        ".//text()[normalize-space()='Add']]")
_SEARCH_BUTTON       = (By.XPATH,
                        "//button[@type='submit' and "
                        ".//text()[normalize-space()='Search']]")

# --- Add Employee form ---
# OrangeHRM v5 name inputs are plain <input> with name attributes
_FIRST_NAME_INPUT    = (By.NAME, "firstName")
_MIDDLE_NAME_INPUT   = (By.NAME, "middleName")
_LAST_NAME_INPUT     = (By.NAME, "lastName")

# Employee ID sits inside a form row; find via its label text
_EMPLOYEE_ID_INPUT   = (By.XPATH,
                        "//label[normalize-space(text())='Employee Id']"
                        "/ancestor::div[contains(@class,'oxd-input-group')]"
                        "//input[@type!='hidden']")

# Save button on the Add Employee form
_SAVE_BTN            = (By.XPATH,
                        "//button[@type='submit' and "
                        ".//text()[normalize-space()='Save']]")

# Success confirmation — URL changes to /editEmployee; also a heading appears
_PERSONAL_DETAILS    = (By.XPATH,
                        "//*[contains(@class,'orangehrm-card-container') or "
                        "contains(@class,'orangehrm-horizontal-padding')]"
                        "//*[contains(text(),'Personal Details') or "
                        "contains(text(),'Employee Information')]")

# --- Employee list table ---
_EMPLOYEE_TABLE_ROWS = (By.CSS_SELECTOR,
                        ".oxd-table-body .oxd-table-row--clickable, "
                        ".oxd-table-body .oxd-table-row")
_EMPLOYEE_TABLE_CELLS = (By.CSS_SELECTOR, ".oxd-table-cell")
_TABLE_HEADERS        = (By.CSS_SELECTOR,
                         ".oxd-table-header .oxd-table-head--title, "
                         ".oxd-table-header .oxd-table-column-header")


class PIMPage(BasePage):
    """Encapsulates interactions with the PIM module."""

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def navigate_to_pim(self) -> "PIMPage":
        """
        Click the PIM item in the sidebar.
        Tries three increasingly broad locator strategies so the code is
        resilient to minor DOM changes in OrangeHRM v5.
        """
        logger.info("Navigating to PIM module…")

        # Strategy 1 – direct href link (most reliable)
        for locator in [_PIM_MENU_LINK, _PIM_MENU_SPAN, _PIM_MENU_TEXT]:
            try:
                el = self.wait.until(
                    EC.element_to_be_clickable(locator)
                )
                self.driver.execute_script("arguments[0].scrollIntoView(true);", el)
                el.click()
                logger.info("PIM menu clicked via locator: %s", locator)
                time.sleep(1.5)   # allow Vue router transition
                return self
            except Exception:  # noqa: BLE001
                logger.debug("PIM locator %s did not work, trying next…", locator)

        # Strategy 4 – JS click by text as last resort
        logger.warning("All CSS/XPath PIM locators failed – trying JS text search.")
        self.driver.execute_script("""
            var spans = document.querySelectorAll('.oxd-main-menu-item--name');
            for (var s of spans) {
                if (s.textContent.trim() === 'PIM') {
                    s.closest('a').click();
                    break;
                }
            }
        """)
        time.sleep(1.5)
        logger.info("PIM menu clicked via JavaScript fallback.")
        return self

    def click_add_employee(self) -> "PIMPage":
        """Click the 'Add' button on the Employee List page."""
        # Wait for Employee List page to settle first
        time.sleep(1)
        try:
            self.safe_click(*_ADD_EMPLOYEE_BTN)
        except Exception:  # noqa: BLE001
            # Fallback: find any button containing text 'Add'
            logger.warning("Primary Add-button locator failed – using JS fallback.")
            self.driver.execute_script("""
                var btns = document.querySelectorAll('button.oxd-button');
                for (var b of btns) {
                    if (b.textContent.trim().includes('Add')) { b.click(); break; }
                }
            """)
        logger.info("Clicked 'Add Employee' button.")
        time.sleep(1)
        return self

    # ------------------------------------------------------------------
    # Add Employee form
    # ------------------------------------------------------------------

    def fill_employee_details(
        self,
        first_name: str,
        last_name: str,
        employee_id: str = "",
        middle_name: str = "",
    ) -> "PIMPage":
        """
        Fill the Add Employee form fields.

        Parameters
        ----------
        first_name   : required
        last_name    : required
        employee_id  : optional – leave empty for OrangeHRM auto-generated ID
        middle_name  : optional
        """
        logger.info(
            "Filling employee form: first='%s', last='%s', id='%s'",
            first_name, last_name, employee_id,
        )

        # Wait for the form to fully render (firstName input appears)
        self.wait_for_visible(*_FIRST_NAME_INPUT)

        self.safe_send_keys(*_FIRST_NAME_INPUT, first_name)

        if middle_name:
            self.safe_send_keys(*_MIDDLE_NAME_INPUT, middle_name)

        self.safe_send_keys(*_LAST_NAME_INPUT, last_name)

        if employee_id:
            try:
                self.safe_send_keys(*_EMPLOYEE_ID_INPUT, employee_id)
            except Exception:  # noqa: BLE001
                # Fallback: Employee ID field by input index in the last form-row
                logger.warning("Employee ID primary locator failed – using index fallback.")
                inputs = self.driver.find_elements(By.CSS_SELECTOR, ".oxd-form input")
                if len(inputs) >= 4:
                    inputs[3].clear()
                    inputs[3].send_keys(employee_id)

        return self

    def save_employee(self) -> bool:
        """
        Click Save and verify success.

        Success is detected by either:
          • The Personal Details heading appearing, OR
          • The URL changing to contain 'editEmployee'
        """
        self.safe_click(*_SAVE_BTN)
        logger.info("Save button clicked – waiting for confirmation…")
        time.sleep(1)

        # Check 1: URL change (most reliable for OrangeHRM v5)
        try:
            self.wait.until(EC.url_contains("editEmployee"))
            logger.info("Employee saved successfully – URL changed to editEmployee.")
            return True
        except TimeoutException:
            pass

        # Check 2: Personal Details heading in page
        try:
            self.wait_for_visible(*_PERSONAL_DETAILS)
            logger.info("Employee saved successfully – Personal Details visible.")
            return True
        except TimeoutException:
            pass

        # Check 3: No error toast visible → assume success
        try:
            toast = self.driver.find_element(
                By.CSS_SELECTOR, ".oxd-toast--error, .oxd-alert--error"
            )
            logger.error("Employee save FAILED – error toast: %s", toast.text)
            return False
        except NoSuchElementException:
            # No error found → treat as success (page may have already transitioned)
            logger.info("No error toast detected – treating save as success.")
            return True

    def add_employee(
        self,
        first_name: str,
        last_name: str,
        employee_id: str = "",
    ) -> bool:
        """
        Full end-to-end flow: navigate PIM → click Add → fill form → save.

        Returns
        -------
        bool  True on success.
        """
        self.navigate_to_pim()
        self.click_add_employee()
        self.fill_employee_details(first_name, last_name, employee_id)
        return self.save_employee()

    # ------------------------------------------------------------------
    # Extract Employee List
    # ------------------------------------------------------------------

    def get_employee_list(self) -> List[Dict[str, str]]:
        """
        Navigate to the Employee List and return all visible rows.

        Returns
        -------
        list[dict]  Each dict represents one employee row keyed by column header.
        """
        self.navigate_to_pim()
        time.sleep(1.5)   # let the list page settle

        employees: List[Dict[str, str]] = []

        try:
            # Trigger search with no filters to load all employees
            try:
                self.safe_click(*_SEARCH_BUTTON)
            except Exception:  # noqa: BLE001
                logger.warning("Search button not found – list may already be loaded.")
            time.sleep(2)

            # Read column headers
            header_elements = self.driver.find_elements(*_TABLE_HEADERS)
            headers = [h.text.strip() for h in header_elements if h.text.strip()]
            logger.debug("Table headers: %s", headers)

            # Robust default headers if DOM query returns nothing
            if not headers:
                headers = [
                    "First & Middle Name", "Last Name",
                    "Employee Id", "Employment Status",
                    "Job Title", "Sub Unit",
                ]

            # Read rows
            rows = self.driver.find_elements(*_EMPLOYEE_TABLE_ROWS)
            logger.info("Employee list rows found: %d", len(rows))

            for row in rows:
                cells = row.find_elements(*_EMPLOYEE_TABLE_CELLS)
                cell_texts = [c.text.strip() for c in cells]

                if not any(cell_texts):
                    continue

                row_data: Dict[str, str] = {}
                for idx, header in enumerate(headers):
                    row_data[header] = cell_texts[idx] if idx < len(cell_texts) else ""
                employees.append(row_data)

        except Exception as exc:  # noqa: BLE001
            logger.error("Error extracting employee list: %s", exc)

        logger.info("Extracted %d employee record(s).", len(employees))
        return employees
