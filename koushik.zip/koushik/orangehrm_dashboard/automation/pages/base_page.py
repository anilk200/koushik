"""
automation/pages/base_page.py
------------------------------
BasePage – shared helpers used by every Page Object.
All page classes inherit from this to avoid duplicating wait logic.
"""

from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException, NoSuchElementException

from orangehrm_dashboard.config import EXPLICIT_WAIT
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("base_page")


class BasePage:
    """Base class for all Page Objects."""

    def __init__(self, driver: WebDriver) -> None:
        self.driver = driver
        self.wait = WebDriverWait(driver, EXPLICIT_WAIT)

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def open(self, url: str) -> None:
        """Navigate to the given URL."""
        logger.debug("Opening URL: %s", url)
        self.driver.get(url)

    def get_title(self) -> str:
        return self.driver.title

    def get_current_url(self) -> str:
        return self.driver.current_url

    # ------------------------------------------------------------------
    # Element helpers
    # ------------------------------------------------------------------

    def find(self, by: By, value: str) -> WebElement:
        return self.driver.find_element(by, value)

    def wait_for_visible(self, by: By, value: str) -> WebElement:
        """Wait until the element is visible, then return it."""
        try:
            return self.wait.until(EC.visibility_of_element_located((by, value)))
        except TimeoutException:
            logger.error("Timed out waiting for element: %s='%s'", by, value)
            raise

    def wait_for_clickable(self, by: By, value: str) -> WebElement:
        """Wait until the element is clickable, then return it."""
        try:
            return self.wait.until(EC.element_to_be_clickable((by, value)))
        except TimeoutException:
            logger.error("Timed out waiting for clickable element: %s='%s'", by, value)
            raise

    def wait_for_text(self, by: By, value: str, text: str) -> WebElement:
        """Wait until the element contains specific text."""
        return self.wait.until(EC.text_to_be_present_in_element((by, value), text))

    def safe_click(self, by: By, value: str) -> None:
        """Wait until clickable, scroll into view, then click."""
        element = self.wait_for_clickable(by, value)
        self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
        element.click()
        logger.debug("Clicked element: %s='%s'", by, value)

    def safe_send_keys(self, by: By, value: str, text: str) -> None:
        """Clear the field and type text."""
        element = self.wait_for_visible(by, value)
        element.clear()
        element.send_keys(text)
        logger.debug("Typed '%s' into element: %s='%s'", text, by, value)

    def is_element_present(self, by: By, value: str) -> bool:
        """Return True if the element exists in the DOM."""
        try:
            self.driver.find_element(by, value)
            return True
        except NoSuchElementException:
            return False

    def take_screenshot(self, path: str) -> None:
        """Save a screenshot to the given path."""
        try:
            self.driver.save_screenshot(path)
            logger.info("Screenshot saved → %s", path)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not save screenshot: %s", exc)
