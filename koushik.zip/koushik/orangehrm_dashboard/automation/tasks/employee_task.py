"""
automation/tasks/employee_task.py
----------------------------------
Orchestrates the complete end-to-end automation flow:
  1. Launch browser
  2. Login to OrangeHRM
  3. Add a new employee via PIM
  4. Extract the employee list
  5. Export data to CSV
  6. Logout
  7. Quit browser

This is the single entry-point called by the Flask API endpoint.
"""

import os
import time
from datetime import datetime
from typing import Any, Dict

from orangehrm_dashboard.automation.driver_setup import get_driver
from orangehrm_dashboard.automation.pages.login_page import LoginPage
from orangehrm_dashboard.automation.pages.pim_page import PIMPage
from orangehrm_dashboard.config import BASE_URL, OUTPUT_DIR
from orangehrm_dashboard.utils.export import export_to_csv, export_to_excel
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("employee_task")

# Logout locator (used inline – no separate page class needed)
_LOGOUT_MENU     = ("css selector", ".oxd-userdropdown-tab")
_LOGOUT_OPTION   = ("xpath",        "//a[normalize-space()='Logout']")


def run_employee_automation(
    username: str,
    password: str,
    first_name: str,
    last_name: str,
    employee_id: str = "",
) -> Dict[str, Any]:
    """
    Execute the full OrangeHRM automation sequence.

    Parameters
    ----------
    username      : OrangeHRM login username
    password      : OrangeHRM login password
    first_name    : New employee first name
    last_name     : New employee last name
    employee_id   : New employee ID (optional)

    Returns
    -------
    dict with keys:
        status      – "success" | "failure"
        message     – human-readable summary
        employee    – dict of the submitted employee data
        employees   – list of extracted employee records
        csv_path    – path to the exported CSV file
        excel_path  – path to the exported Excel file
        screenshot  – path to a post-save screenshot
        logs        – list of step log messages
    """
    step_logs: list[str] = []
    result: Dict[str, Any] = {
        "status": "failure",
        "message": "",
        "employee": {
            "first_name": first_name,
            "last_name": last_name,
            "employee_id": employee_id,
        },
        "employees": [],
        "csv_path": "",
        "excel_path": "",
        "screenshot": "",
        "logs": step_logs,
    }

    driver = None
    try:
        # ----------------------------------------------------------------
        # Step 1 – Launch browser
        # ----------------------------------------------------------------
        _log(step_logs, "Step 1: Launching browser…")
        driver = get_driver()

        # ----------------------------------------------------------------
        # Step 2 – Login
        # ----------------------------------------------------------------
        _log(step_logs, f"Step 2: Logging in as '{username}'…")
        login_page = LoginPage(driver)
        login_page.load(BASE_URL)
        login_ok = login_page.login(username, password)

        if not login_ok:
            result["message"] = "Login failed – check credentials."
            _log(step_logs, "ERROR: Login failed.")
            return result

        _log(step_logs, "Login successful.")

        # ----------------------------------------------------------------
        # Step 3 – Add Employee
        # ----------------------------------------------------------------
        _log(step_logs, f"Step 3: Adding employee '{first_name} {last_name}'…")
        pim_page = PIMPage(driver)
        add_ok = pim_page.add_employee(first_name, last_name, employee_id)

        if not add_ok:
            result["message"] = "Employee creation failed."
            _log(step_logs, "ERROR: Employee could not be saved.")
            return result

        _log(step_logs, "Employee added successfully.")

        # ----------------------------------------------------------------
        # Step 4 – Screenshot after save
        # ----------------------------------------------------------------
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        screenshot_path = os.path.join(OUTPUT_DIR, f"employee_saved_{ts}.png")
        login_page.take_screenshot(screenshot_path)
        result["screenshot"] = screenshot_path
        _log(step_logs, f"Step 4: Screenshot saved → {screenshot_path}")

        # ----------------------------------------------------------------
        # Step 5 – Extract employee list
        # ----------------------------------------------------------------
        _log(step_logs, "Step 5: Extracting employee list…")
        employees = pim_page.get_employee_list()
        result["employees"] = employees
        _log(step_logs, f"Extracted {len(employees)} employee record(s).")

        # ----------------------------------------------------------------
        # Step 6 – Export data
        # ----------------------------------------------------------------
        _log(step_logs, "Step 6: Exporting data to CSV and Excel…")
        csv_path = export_to_csv(employees, f"employees_{ts}.csv")
        excel_path = export_to_excel(employees, f"employees_{ts}.xlsx")
        result["csv_path"] = csv_path
        result["excel_path"] = excel_path

        # ----------------------------------------------------------------
        # Step 7 – Logout
        # ----------------------------------------------------------------
        _log(step_logs, "Step 7: Logging out…")
        try:
            driver.find_element(*_LOGOUT_MENU).click()
            time.sleep(1)
            driver.find_element(*_LOGOUT_OPTION).click()
            _log(step_logs, "Logged out successfully.")
        except Exception as exc:  # noqa: BLE001
            _log(step_logs, f"Logout warning (non-critical): {exc}")

        # ----------------------------------------------------------------
        # Done
        # ----------------------------------------------------------------
        result["status"] = "success"
        result["message"] = (
            f"Automation complete. Employee '{first_name} {last_name}' "
            f"added. {len(employees)} records extracted."
        )
        _log(step_logs, "Automation completed successfully.")

    except Exception as exc:  # noqa: BLE001
        logger.exception("Unhandled error in automation task")
        result["message"] = f"Unexpected error: {exc}"
        _log(step_logs, f"FATAL ERROR: {exc}")

    finally:
        if driver:
            driver.quit()
            logger.info("Browser closed.")

    return result


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _log(log_list: list, message: str) -> None:
    """Append a timestamped message to the step log list and the file logger."""
    ts = datetime.now().strftime("%H:%M:%S")
    entry = f"[{ts}] {message}"
    log_list.append(entry)
    logger.info(message)
