"""
automation/driver_setup.py
--------------------------
Factory that creates and returns a configured Selenium WebDriver instance.
Supports Chrome, Firefox, and Edge.

ChromeDriver version matching strategy (in order):
  1. Selenium 4.6+ built-in Selenium Manager   → auto-matches installed Chrome
  2. webdriver-manager with version pinning     → reads installed Chrome version
  3. Bare webdriver.Chrome()                    → relies on PATH chromedriver

This avoids the common "ChromeDriver X only supports Chrome Y" mismatch where
webdriver-manager downloads the latest driver instead of the one matching the
currently installed Chrome binary.
"""

import re
import subprocess
import sys
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.edge.options import Options as EdgeOptions

try:
    from webdriver_manager.chrome import ChromeDriverManager
    from webdriver_manager.core.os_manager import ChromeType
    from webdriver_manager.firefox import GeckoDriverManager
    from webdriver_manager.microsoft import EdgeChromiumDriverManager
    _WDM_AVAILABLE = True
except ImportError:
    _WDM_AVAILABLE = False

from orangehrm_dashboard.config import (
    BROWSER, HEADLESS, IMPLICIT_WAIT, PAGE_LOAD_TIMEOUT
)
from orangehrm_dashboard.utils.logger import get_logger

logger = get_logger("driver_setup")

# Well-known Chrome binary paths on Windows
_CHROME_PATHS_WIN = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Users\{user}\AppData\Local\Google\Chrome\Application\chrome.exe",
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def get_driver() -> webdriver.Remote:
    """
    Create and return a WebDriver instance based on the BROWSER config value.

    Returns
    -------
    selenium.webdriver.Remote  (concrete Chrome / Firefox / Edge instance)

    Raises
    ------
    ValueError   if an unsupported browser is specified
    RuntimeError if the driver cannot be initialised
    """
    browser = BROWSER.lower().strip()
    logger.info("Initialising %s driver  (headless=%s)", browser, HEADLESS)

    try:
        if browser == "chrome":
            driver = _build_chrome()
        elif browser in ("firefox", "gecko"):
            driver = _build_firefox()
        elif browser == "edge":
            driver = _build_edge()
        else:
            raise ValueError(
                f"Unsupported browser: '{browser}'. Choose chrome / firefox / edge."
            )

        driver.implicitly_wait(IMPLICIT_WAIT)
        driver.set_page_load_timeout(PAGE_LOAD_TIMEOUT)
        driver.maximize_window()
        logger.info("WebDriver ready.")
        return driver

    except Exception as exc:
        logger.error("Failed to create WebDriver: %s", exc)
        raise RuntimeError(f"WebDriver initialisation failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Private builder helpers
# ---------------------------------------------------------------------------

def _chrome_options() -> ChromeOptions:
    """Return a fully configured ChromeOptions object."""
    opts = ChromeOptions()
    if HEADLESS:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    opts.add_experimental_option("useAutomationExtension", False)
    return opts


def _get_installed_chrome_major_version() -> str | None:
    """
    Detect the major version of the Chrome binary installed on this machine.
    Returns e.g. "151" or None if detection fails.
    """
    # Strategy 1: query chrome.exe directly (Windows)
    for path_template in _CHROME_PATHS_WIN:
        import os
        path = path_template.replace("{user}", os.environ.get("USERNAME", ""))
        if Path(path).exists():
            try:
                out = subprocess.check_output(
                    [path, "--version"], stderr=subprocess.DEVNULL, timeout=5
                ).decode().strip()
                # "Google Chrome 151.0.7922.109"
                match = re.search(r"(\d+)\.\d+\.\d+\.\d+", out)
                if match:
                    ver = match.group(1)
                    logger.info("Detected Chrome version: %s (from %s)", out, path)
                    return ver
            except Exception:  # noqa: BLE001
                pass

    # Strategy 2: ask wmic (Windows legacy)
    try:
        out = subprocess.check_output(
            ["wmic", "datafile", "where",
             r'name="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"',
             "get", "Version", "/value"],
            stderr=subprocess.DEVNULL, timeout=5
        ).decode()
        match = re.search(r"Version=(\d+)\.", out)
        if match:
            ver = match.group(1)
            logger.info("Detected Chrome major version via wmic: %s", ver)
            return ver
    except Exception:  # noqa: BLE001
        pass

    logger.warning("Could not detect installed Chrome version automatically.")
    return None


def _build_chrome() -> webdriver.Chrome:
    opts = _chrome_options()

    # ------------------------------------------------------------------
    # Strategy A: Selenium Manager (built into Selenium 4.6+)
    # Selenium Manager automatically matches the driver to the installed
    # Chrome – no extra code needed, just pass options without a Service.
    # ------------------------------------------------------------------
    logger.info("Trying Selenium Manager (auto-match)…")
    try:
        driver = webdriver.Chrome(options=opts)
        logger.info("Chrome launched via Selenium Manager.")
        return driver
    except Exception as sm_exc:
        logger.warning("Selenium Manager failed (%s) – falling back to webdriver-manager.", sm_exc)

    # ------------------------------------------------------------------
    # Strategy B: webdriver-manager pinned to installed Chrome version
    # ------------------------------------------------------------------
    if _WDM_AVAILABLE:
        chrome_major = _get_installed_chrome_major_version()
        logger.info(
            "Using webdriver-manager  (pinned version=%s)…",
            chrome_major or "latest",
        )
        try:
            manager = ChromeDriverManager(driver_version=chrome_major) if chrome_major \
                      else ChromeDriverManager()
            service = ChromeService(manager.install())
            driver = webdriver.Chrome(service=service, options=opts)
            logger.info("Chrome launched via webdriver-manager (version=%s).", chrome_major)
            return driver
        except Exception as wdm_exc:
            logger.warning("webdriver-manager failed (%s) – trying bare driver.", wdm_exc)

    # ------------------------------------------------------------------
    # Strategy C: bare webdriver – relies on chromedriver already in PATH
    # ------------------------------------------------------------------
    logger.info("Attempting bare webdriver.Chrome() (chromedriver must be in PATH)…")
    return webdriver.Chrome(options=opts)


def _build_firefox() -> webdriver.Firefox:
    opts = FirefoxOptions()
    if HEADLESS:
        opts.add_argument("--headless")

    try:
        return webdriver.Firefox(options=opts)
    except Exception:  # noqa: BLE001
        pass

    if _WDM_AVAILABLE:
        service = FirefoxService(GeckoDriverManager().install())
        return webdriver.Firefox(service=service, options=opts)

    return webdriver.Firefox(options=opts)


def _build_edge() -> webdriver.Edge:
    opts = EdgeOptions()
    if HEADLESS:
        opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")

    try:
        return webdriver.Edge(options=opts)
    except Exception:  # noqa: BLE001
        pass

    if _WDM_AVAILABLE:
        service = EdgeService(EdgeChromiumDriverManager().install())
        return webdriver.Edge(service=service, options=opts)

    return webdriver.Edge(options=opts)
