"""
config.py
---------
Centralised configuration for OrangeHRM Dashboard Automation.
Credentials are read from environment variables so nothing sensitive
is hard-coded in source.  A .env file (never committed) can be used
locally via python-dotenv.
"""

import os
from dotenv import load_dotenv

# Load a local .env file if it exists (ignored in production)
load_dotenv()

# ---------------------------------------------------------------------------
# OrangeHRM target site
# ---------------------------------------------------------------------------
BASE_URL: str = os.getenv("ORANGEHRM_URL", "https://opensource-demo.orangehrmlive.com")

# ---------------------------------------------------------------------------
# Default credentials (overridden by environment variables / dashboard input)
# ---------------------------------------------------------------------------
DEFAULT_USERNAME: str = os.getenv("ORANGEHRM_USER", "Admin")
DEFAULT_PASSWORD: str = os.getenv("ORANGEHRM_PASS", "admin123")

# ---------------------------------------------------------------------------
# WebDriver settings
# ---------------------------------------------------------------------------
BROWSER: str = os.getenv("BROWSER", "chrome")          # chrome | firefox | edge
HEADLESS: bool = os.getenv("HEADLESS", "true").lower() == "true"
IMPLICIT_WAIT: int = int(os.getenv("IMPLICIT_WAIT", "10"))
EXPLICIT_WAIT: int = int(os.getenv("EXPLICIT_WAIT", "20"))
PAGE_LOAD_TIMEOUT: int = int(os.getenv("PAGE_LOAD_TIMEOUT", "30"))

# ---------------------------------------------------------------------------
# Output directories
# ---------------------------------------------------------------------------
BASE_DIR: str = os.path.dirname(os.path.abspath(__file__))
LOG_DIR: str = os.path.join(BASE_DIR, "logs")
OUTPUT_DIR: str = os.path.join(BASE_DIR, "output")

# Ensure directories exist at import time
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# Flask settings
# ---------------------------------------------------------------------------
FLASK_HOST: str = os.getenv("FLASK_HOST", "127.0.0.1")
FLASK_PORT: int = int(os.getenv("FLASK_PORT", "5000"))
FLASK_DEBUG: bool = os.getenv("FLASK_DEBUG", "false").lower() == "true"
SECRET_KEY: str = os.getenv("SECRET_KEY", "orangehrm-dashboard-secret-2024")
