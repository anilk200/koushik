/**
 * main.js
 * -------
 * Client-side logic for the OrangeHRM Dashboard Automation UI.
 * Handles form submission, displays results, renders the employee table.
 */

'use strict';

// ============================================================
// DOM references
// ============================================================
const form           = document.getElementById('automation-form');
const submitBtn      = document.getElementById('submit-btn');
const btnLabel       = document.getElementById('btn-label');
const btnSpinner     = document.getElementById('btn-spinner');

const statusBanner   = document.getElementById('status-banner');
const employeeSum    = document.getElementById('employee-summary');
const sFirst         = document.getElementById('s-first');
const sLast          = document.getElementById('s-last');
const sId            = document.getElementById('s-id');

const logSection     = document.getElementById('log-section');
const logOutput      = document.getElementById('log-output');

const downloadSection = document.getElementById('download-section');
const downloadLinks   = document.getElementById('download-links');

const tableSection   = document.getElementById('table-section');
const tableHead      = document.getElementById('table-head');
const tableBody      = document.getElementById('table-body');

const idlePlaceholder = document.getElementById('idle-placeholder');

// ============================================================
// Form submit
// ============================================================
form.addEventListener('submit', async (e) => {
  e.preventDefault();

  if (!validateForm()) return;

  setLoading(true);
  clearResults();

  const payload = {
    username:    form.username.value.trim(),
    password:    form.password.value.trim(),
    first_name:  form.first_name.value.trim(),
    last_name:   form.last_name.value.trim(),
    employee_id: form.employee_id.value.trim(),
  };

  try {
    const response = await fetch('/run', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });

    const result = await response.json();
    displayResults(result, payload);

  } catch (err) {
    displayError(`Network error: ${err.message}`);
  } finally {
    setLoading(false);
  }
});

// ============================================================
// Validation
// ============================================================
function validateForm() {
  let valid = true;
  ['username', 'password', 'first_name', 'last_name'].forEach(field => {
    const el = form[field];
    if (!el.value.trim()) {
      el.classList.add('error');
      valid = false;
    } else {
      el.classList.remove('error');
    }
  });
  return valid;
}

// Remove error class on input
form.querySelectorAll('.input').forEach(input => {
  input.addEventListener('input', () => input.classList.remove('error'));
});

// ============================================================
// Display results
// ============================================================
function displayResults(result, payload) {
  idlePlaceholder.classList.add('hidden');

  // Status banner
  statusBanner.classList.remove('hidden', 'success', 'error');
  if (result.status === 'success') {
    statusBanner.classList.add('success');
    statusBanner.innerHTML = `&#9989; ${escapeHtml(result.message)}`;
  } else {
    statusBanner.classList.add('error');
    statusBanner.innerHTML = `&#10060; ${escapeHtml(result.message)}`;
  }

  // Employee summary (always show what was submitted)
  sFirst.textContent = payload.first_name;
  sLast.textContent  = payload.last_name;
  sId.textContent    = payload.employee_id || '(auto-generated)';
  employeeSum.classList.remove('hidden');

  // Step logs
  if (result.logs && result.logs.length) {
    logOutput.innerHTML = result.logs
      .map(line => {
        const cls = line.includes('ERROR') || line.includes('FATAL')
          ? 'error-line'
          : line.includes('warn') || line.includes('warning')
          ? 'warn-line'
          : '';
        return `<p class="${cls}">${escapeHtml(line)}</p>`;
      })
      .join('');
    logSection.classList.remove('hidden');
  }

  // Download links
  const links = [];
  if (result.csv_path) {
    links.push({ href: `/download/${result.csv_path}`, label: '&#128196; Download CSV' });
  }
  if (result.excel_path) {
    links.push({ href: `/download/${result.excel_path}`, label: '&#128202; Download Excel' });
  }
  if (result.screenshot) {
    links.push({ href: `/download/${result.screenshot}`, label: '&#128247; Screenshot' });
  }

  if (links.length) {
    downloadLinks.innerHTML = links
      .map(l => `<a class="dl-btn" href="${l.href}" target="_blank">${l.label}</a>`)
      .join('');
    downloadSection.classList.remove('hidden');
  }

  // Employee table
  if (result.employees && result.employees.length) {
    renderTable(result.employees);
    tableSection.classList.remove('hidden');
  }
}

function displayError(message) {
  idlePlaceholder.classList.add('hidden');
  statusBanner.classList.remove('hidden', 'success');
  statusBanner.classList.add('error');
  statusBanner.innerHTML = `&#10060; ${escapeHtml(message)}`;
}

// ============================================================
// Render employee table
// ============================================================
function renderTable(employees) {
  const headers = Object.keys(employees[0]);

  // Header row
  tableHead.innerHTML = '<tr>' +
    headers.map(h => `<th>${escapeHtml(h)}</th>`).join('') +
    '</tr>';

  // Data rows
  tableBody.innerHTML = employees.map(emp =>
    '<tr>' +
    headers.map(h => `<td>${escapeHtml(emp[h] || '')}</td>`).join('') +
    '</tr>'
  ).join('');
}

// ============================================================
// Helpers
// ============================================================
function setLoading(loading) {
  submitBtn.disabled = loading;
  if (loading) {
    btnLabel.classList.add('hidden');
    btnSpinner.classList.remove('hidden');
  } else {
    btnLabel.classList.remove('hidden');
    btnSpinner.classList.add('hidden');
  }
}

function clearResults() {
  [statusBanner, employeeSum, logSection, downloadSection, tableSection]
    .forEach(el => el.classList.add('hidden'));
  statusBanner.className = 'status-banner hidden';
  logOutput.innerHTML = '';
  downloadLinks.innerHTML = '';
  tableHead.innerHTML = '';
  tableBody.innerHTML = '';
  idlePlaceholder.classList.remove('hidden');
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function togglePassword() {
  const pw = document.getElementById('password');
  pw.type = pw.type === 'password' ? 'text' : 'password';
}
