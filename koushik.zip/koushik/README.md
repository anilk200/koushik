# OrangeHRM Dashboard Automation

A **Flask-based dashboard** that lets you enter employee details in a browser UI and triggers **Selenium automation** against [OrangeHRM Demo](https://opensource-demo.orangehrmlive.com) — all from a single click.

---

## Features

| Feature | Detail |
|---|---|
| **Dashboard UI** | Clean HTML/CSS form – no framework needed |
| **Login** | Credentials entered on dashboard, never hard-coded |
| **Add Employee** | PIM → Add Employee flow automated via Selenium |
| **Employee List** | Extracts visible employee table from OrangeHRM |
| **CSV / Excel Export** | Downloads generated in `orangehrm_dashboard/output/` |
| **Step Logs** | Every automation step logged to file + shown on dashboard |
| **Screenshot** | Captured after successful save |

---

## Project Structure

```
orangehrm_dashboard/
├── app.py                        # Flask backend & API routes
├── config.py                     # Centralised config (env-driven)
├── automation/
│   ├── driver_setup.py           # WebDriver factory (Chrome/Firefox/Edge)
│   └── pages/
│       ├── base_page.py          # Shared Selenium helpers
│       ├── login_page.py         # POM – Login screen
│       └── pim_page.py           # POM – PIM / Employee management
│   └── tasks/
│       └── employee_task.py      # Orchestrates the full automation flow
├── utils/
│   ├── logger.py                 # Rotating file + console logger
│   └── export.py                 # CSV & Excel export helpers
├── templates/
│   └── index.html                # Dashboard HTML
├── static/
│   ├── css/style.css             # Dashboard styles
│   └── js/main.js                # Dashboard JS (fetch API)
├── logs/                         # Auto-created – daily log files
└── output/                       # Auto-created – CSV, Excel, screenshots
requirements.txt
.env.template                     # Copy to .env and fill credentials
```

---

## Quick Start

### 1 – Clone / extract

```bash
cd orangehrm_dashboard
```

### 2 – Create virtual environment

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate
```

### 3 – Install dependencies

```bash
pip install -r requirements.txt
```

### 4 – Configure environment

```bash
copy .env.template .env     # Windows
cp  .env.template .env      # macOS/Linux
# Edit .env – change SECRET_KEY in production
```

### 5 – Run the dashboard

```bash
python -m orangehrm_dashboard.app
```

Open **http://127.0.0.1:5000** in your browser.

---

## Usage

1. Enter **username / password** (defaults pre-filled from `.env`).
2. Enter **First Name**, **Last Name**, and optionally **Employee ID**.
3. Click **Run Automation**.
4. Watch the step logs and results appear on the right panel.
5. Download the **CSV** or **Excel** file of the extracted employee list.

---

## Configuration

All settings live in **`.env`** (copied from `.env.template`):

| Variable | Default | Description |
|---|---|---|
| `ORANGEHRM_URL` | demo URL | Target OrangeHRM instance |
| `ORANGEHRM_USER` | `Admin` | Default login username |
| `ORANGEHRM_PASS` | `admin123` | Default login password |
| `BROWSER` | `chrome` | `chrome` / `firefox` / `edge` |
| `HEADLESS` | `true` | Run browser headless |
| `FLASK_PORT` | `5000` | Port for the Flask server |

---

## API Reference

### `POST /run`

Trigger automation programmatically.

**Request body (JSON):**
```json
{
  "username":    "Admin",
  "password":    "admin123",
  "first_name":  "John",
  "last_name":   "Doe",
  "employee_id": "EMP001"
}
```

**Response (JSON):**
```json
{
  "status":     "success",
  "message":    "Automation complete...",
  "employee":   { "first_name": "John", "last_name": "Doe", "employee_id": "EMP001" },
  "employees":  [ { "First & Middle Name": "...", ... } ],
  "csv_path":   "employees_20241215_120000.csv",
  "excel_path": "employees_20241215_120000.xlsx",
  "screenshot": "employee_saved_20241215_120000.png",
  "logs":       [ "[12:00:01] Step 1: Launching browser…", "..." ]
}
```

### `GET /download/<filename>`

Download a file from the `output/` directory.

### `GET /status`

Health check – returns `{"status": "ok"}`.

---

## Requirements

- Python 3.10+
- Google Chrome (or Firefox / Edge) installed
- Internet access to reach the OrangeHRM demo site

---

## Notes

- `webdriver-manager` automatically downloads the correct ChromeDriver – no manual setup needed.
- Credentials flow **from the dashboard → Flask → Selenium** – nothing is hard-coded.
- Logs are saved under `orangehrm_dashboard/logs/` (rotating, max 5 MB each).
- Output files are saved under `orangehrm_dashboard/output/`.
