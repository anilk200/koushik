# RPA Practical Assignment – Dashboard-Driven Automation

## Website Used for Automation
https://opensource-demo.orangehrmlive.com

## Objective
Build a simple frontend dashboard where the user enters automation details. Using the dashboard inputs, automate login and employee operations on the OrangeHRM website.

All actions must be triggered and controlled from the dashboard.

---

# Dashboard Requirements (Frontend)

- Create a basic dashboard using HTML/CSS (optional JS / Flask / FastAPI).
- Dashboard should contain fields for login credentials.
- Dashboard should contain fields to enter employee details:
  - First Name
  - Last Name
  - Employee ID
- Submit button to trigger automation.
- Display inserted employee data back on the dashboard after automation.

## Login Credentials (Default for Demo)

- **Username:** Admin
- **Password:** admin123

---

# Automation Tasks (Triggered from Dashboard)

- Open OrangeHRM website.
- Login using credentials provided in the dashboard.
- Navigate to the PIM section.
- Add a new employee using dashboard-provided details.
- Verify employee creation success.
- Extract employee list data.
- Logout from the application.

---

# Data Display on Dashboard

- Show the employee details that were inserted.
- Show success/failure status of automation.
- Optionally display extracted employee table data.

---

# Technical Requirements

- Automation using Python (Selenium / Playwright).
- Dashboard using HTML/CSS with Flask or FastAPI backend.
- Use proper waits and exception handling.
- Credentials should not be hardcoded.
- Maintain logs for each automation step.

---

# Deliverables

- Source code (GitHub repository or ZIP).
- Dashboard UI files (HTML/CSS).
- Automation script.
- Screenshots of dashboard before and after execution.
- CSV/Excel file of extracted data.

---

# Evaluation Criteria

- Dashboard-driven automation flow.
- Correct login and employee creation.
- Data displayed correctly on dashboard.
- Code quality and error handling.